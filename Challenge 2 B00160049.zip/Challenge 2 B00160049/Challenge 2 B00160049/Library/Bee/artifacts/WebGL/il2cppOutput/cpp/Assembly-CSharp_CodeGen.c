﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





extern void DestroyOutOfBoundsX_Update_m6EF605EBDDFA9B6F8A1FB3E410B9F1D738F6DEB0 (void);
extern void DestroyOutOfBoundsX__ctor_m73AC649204523A4E25B9C749204B296587F626D8 (void);
extern void DetectCollisionsX_OnTriggerEnter_m2F9EE3523A07AA7657949CBE990A2928D67547E8 (void);
extern void DetectCollisionsX__ctor_m671ECF652ABEF7E6F12B3E61A79A06A8FD45BF6F (void);
extern void MoveForwardX_Update_m5AE5A2F7E8F16C5751BBEB5FE45D4DDF70EF55A1 (void);
extern void MoveForwardX__ctor_mA480D3EFD0842581C923615DFF6C875C21CF95B6 (void);
extern void PlayerControllerX_Update_mE690DFA5B4D44A839AC48EC903E382790B5CCC8B (void);
extern void PlayerControllerX__ctor_m3FFA731641AD6FA1CE627820042B7587E98D535A (void);
extern void SpawnManagerX_Start_mF974670676EF98526100450B651ABED6529E8FD0 (void);
extern void SpawnManagerX_SpawnRandomBall_mAC09861578B77B6E4539709D4579EEE3F03712A0 (void);
extern void SpawnManagerX__ctor_m967D2E81B63EF3B6BCA2C206459FFAB7EBFFE60E (void);
extern void UnitySourceGeneratedAssemblyMonoScriptTypes_v1_Get_mBEB95BEB954BB63E9710BBC7AD5E78C4CB0A0033 (void);
extern void UnitySourceGeneratedAssemblyMonoScriptTypes_v1__ctor_mE70FB23ACC1EA12ABC948AA22C2E78B2D0AA39B1 (void);
static Il2CppMethodPointer s_methodPointers[13] = 
{
	DestroyOutOfBoundsX_Update_m6EF605EBDDFA9B6F8A1FB3E410B9F1D738F6DEB0,
	DestroyOutOfBoundsX__ctor_m73AC649204523A4E25B9C749204B296587F626D8,
	DetectCollisionsX_OnTriggerEnter_m2F9EE3523A07AA7657949CBE990A2928D67547E8,
	DetectCollisionsX__ctor_m671ECF652ABEF7E6F12B3E61A79A06A8FD45BF6F,
	MoveForwardX_Update_m5AE5A2F7E8F16C5751BBEB5FE45D4DDF70EF55A1,
	MoveForwardX__ctor_mA480D3EFD0842581C923615DFF6C875C21CF95B6,
	PlayerControllerX_Update_mE690DFA5B4D44A839AC48EC903E382790B5CCC8B,
	PlayerControllerX__ctor_m3FFA731641AD6FA1CE627820042B7587E98D535A,
	SpawnManagerX_Start_mF974670676EF98526100450B651ABED6529E8FD0,
	SpawnManagerX_SpawnRandomBall_mAC09861578B77B6E4539709D4579EEE3F03712A0,
	SpawnManagerX__ctor_m967D2E81B63EF3B6BCA2C206459FFAB7EBFFE60E,
	UnitySourceGeneratedAssemblyMonoScriptTypes_v1_Get_mBEB95BEB954BB63E9710BBC7AD5E78C4CB0A0033,
	UnitySourceGeneratedAssemblyMonoScriptTypes_v1__ctor_mE70FB23ACC1EA12ABC948AA22C2E78B2D0AA39B1,
};
static const int32_t s_InvokerIndices[13] = 
{
	1126,
	1126,
	953,
	1126,
	1126,
	1126,
	1126,
	1126,
	1126,
	1126,
	1126,
	2166,
	1126,
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule = 
{
	"Assembly-CSharp.dll",
	13,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
